SELECT * FROM users;


