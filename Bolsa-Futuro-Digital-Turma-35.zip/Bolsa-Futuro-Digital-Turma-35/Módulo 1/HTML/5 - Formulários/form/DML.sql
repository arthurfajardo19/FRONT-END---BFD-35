INSERT INTO users (name, email) VALUES
('Ana Silva', 'ana.silva@example.com'),
('Bruno Oliveira', 'bruno.oliveira@example.com'),
('Carla Mendes', 'carla.mendes@example.com'),
('Diego Costa', 'diego.costa@example.com'),
('Fernanda Lima', 'fernanda.lima@example.com');

INSERT INTO users (name, email) VALUES
('Gustavo Rocha', 'gustavo@example.com'),
('Helena Santos', 'helena@exemple.com');

